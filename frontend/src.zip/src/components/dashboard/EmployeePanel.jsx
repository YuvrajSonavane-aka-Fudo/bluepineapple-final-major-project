// src/components/dashboard/EmployeePanel.jsx
import { useRef, useCallback, useEffect } from 'react';
import { parseISO, isToday } from 'date-fns';
import { Box, Typography } from '@mui/material';
import LeaveCell from '../shared/LeaveCell';

const CELL_W   = 35;
const ROW_H    = 35;
const FROZEN_W = 300;
const TODAY_BORDER = '#994545';

export default function EmployeePanel({
  dateStrip = [], employees = [], loading,
  globalSearch = '',
  searchMode = 'EMP',
  onCellClick,
  scrollRef,
  headerScrollRef,
  projScrollRef,
  showAll = true,
}) {
  const rowRefs  = useRef([]);
  const syncing  = useRef(false);
  const bodyRef  = useRef(null);

  // --- sync helper ---
  const syncAll = useCallback((scrollLeft) => {
    if (syncing.current) return;
    syncing.current = true;
    rowRefs.current.forEach(el => { if (el) el.scrollLeft = scrollLeft; });
    if (headerScrollRef?.current) headerScrollRef.current.scrollLeft = scrollLeft;
    if (projScrollRef?.current)   projScrollRef.current.scrollLeft   = scrollLeft;
    syncing.current = false;
  }, [headerScrollRef, projScrollRef]);

  // Expose first row's scroll position via scrollRef so SharedHeader can init
  useEffect(() => {
    if (scrollRef) scrollRef.current = rowRefs.current[0] || null;
  });

  // Horizontal wheel on body
  useEffect(() => {
    const el = bodyRef.current;
    if (!el) return;
    const handler = (e) => {
      if (Math.abs(e.deltaX) < Math.abs(e.deltaY)) return;
      e.preventDefault();
      const first = rowRefs.current.find(Boolean);
      const current = first?.scrollLeft || 0;
      syncAll(Math.max(0, current + e.deltaX));
    };
    el.addEventListener('wheel', handler, { passive: false });
    return () => el.removeEventListener('wheel', handler);
  }, [syncAll]);

  const filtered = employees.filter(emp => {
    if (searchMode === 'EMP' && globalSearch && !emp.full_name.toLowerCase().includes(globalSearch.toLowerCase())) return false;
    if (!showAll) return Object.values(emp.cells || {}).some(c => c !== null);
    return true;
  });

  const todayIdx  = dateStrip.findIndex(d => isToday(parseISO(d.date)));
  const todayLeft = todayIdx >= 0 ? todayIdx * CELL_W : null;

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden', background: '#ffffff' }}>
      <Box ref={bodyRef} sx={{ flex: 1, overflowY: 'auto' }}>
        {loading
          ? <LoadingRows />
          : filtered.length === 0
            ? <EmptyState searchValue={globalSearch} />
            : filtered.map((emp, idx) => {
                const leaveCount = Object.values(emp.cells || {}).filter(c => c !== null).length;
                return (
                  <Box key={emp.user_id} sx={{ display: 'flex', alignItems: 'stretch' }}>
                    {/* Frozen label */}
                    <Box sx={{
                      width: FROZEN_W, minWidth: FROZEN_W, display: 'flex', alignItems: 'center',
                      px: 1.5, background: '#ffffff', borderRight: '2px solid #c8cdd6',
                      borderBottom: '1px solid #e8eaed', flexShrink: 0, gap: 1,
                      height: ROW_H, boxSizing: 'border-box',
                    }}>
                      <Typography sx={{ fontSize: 11, color: '#9aa0ad', fontFamily: "'DM Mono', monospace", flexShrink: 0, minWidth: 40 }}>
                        #{emp.user_id.toString().padStart(4, '0')}
                      </Typography>
                      <Typography sx={{ fontSize: 13, fontWeight: 600, color: '#1a1f2e', flex: 1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                        {emp.full_name}
                      </Typography>
                      <Box sx={{ background: '#eef2ff', border: '1px solid #c7d2fe', borderRadius: 99, px: 1, py: '2px', flexShrink: 0 }}>
                        <Typography sx={{ fontSize: 11, fontWeight: 700, color: '#4338ca', fontFamily: "'DM Mono', monospace" }}>
                          {leaveCount.toFixed(1)}
                        </Typography>
                      </Box>
                    </Box>

                    {/* Scrollable cells */}
                    <Box
                      ref={el => { rowRefs.current[idx] = el; }}
                      onScroll={e => syncAll(e.currentTarget.scrollLeft)}
                      sx={{ flex: 1, overflowX: 'hidden', overflowY: 'hidden', display: 'flex', alignItems: 'flex-start', scrollbarWidth: 'none', '&::-webkit-scrollbar': { display: 'none' }, position: 'relative' }}
                    >
                      {todayLeft !== null && (
                        <Box sx={{ position: 'absolute', top: 0, left: todayLeft, width: CELL_W, height: '100%', borderLeft: `1px solid ${TODAY_BORDER}`, borderRight: `1px solid ${TODAY_BORDER}`, pointerEvents: 'none', zIndex: 10, boxSizing: 'border-box' }} />
                      )}
                      <Box sx={{ display: 'flex', height: ROW_H }}>
                        {dateStrip.map((d, di) => (
                          <LeaveCell key={d.date} cell={emp.cells?.[d.date]} dateInfo={d} isFirst={di === 0} onClick={(rect) => onCellClick(emp, d.date, rect)} />
                        ))}
                      </Box>
                    </Box>
                  </Box>
                );
              })
        }
      </Box>
    </Box>
  );
}

function LoadingRows() {
  return (
    <Box sx={{ p: 2, display: 'flex', flexDirection: 'column', gap: 1 }}>
      {[1, 2, 3].map(i => (
        <Box key={i} sx={{ height: 35, borderRadius: '4px', background: 'linear-gradient(90deg,#f0f2f5 0%,#e8eaed 50%,#f0f2f5 100%)' }} />
      ))}
    </Box>
  );
}

function EmptyState({ searchValue }) {
  return (
    <Box sx={{ p: 5, textAlign: 'center' }}>
      <Typography sx={{ fontSize: 13, color: '#9aa0ad' }}>
        {searchValue ? `No employees matching "${searchValue}"` : 'No leave records in this period'}
      </Typography>
    </Box>
  );
}